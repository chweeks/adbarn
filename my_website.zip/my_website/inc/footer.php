<footer class="tc">
      <div class="container">
        <div class="row">

          <div class="col-md-3">
            <h4>About</h4>
            <ul>
              <li><a href="vision.php">Our vision</a></li>
              <li><a href="contact.php">Contact us</a></li>
              <li><a href="terms.php">Terms & Privacy</a></li>
             
            </ul>
          </div>
            <div class="col-md-3">
            <h4>Resources</h4>
            <ul>
              <li><a href="faq.php">FAQ</a></li>
              <li><a href="glossary.php">Glossary</a></li>
              <li><a href="tutorials.php">Tutorials</a></li>
              <li><a href="blog.php">Blog</a></li>
              <li><a href="translations.php">Translations</a></li>
            </ul>
          </div>
          <div class="col-md-3">
            <h4>Affiliate</h4>
            <ul>
              <li><a href="packages.php">Packages</a></li>
              <li><a href="badges.php">Badges</a></li>
              <li>&nbsp;</li>
              <li>
              <a href="login.php" class="btn btn-default">
                 Affiliate Program
              </a>
              </li>
            </ul>
          </div>
          <div class="col-md-3 payment">
            <h4>Payments</h4>
            <img src="img/paypal-logo.png"> <br/>
            <img src="img/payoneer-logo.png">
          </div>

        </div>
      </div>
    </footer>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
    <script type="text/javascript" src="//adbarn.com/js/bootstrap.js"></script>

  </body>
</html>
