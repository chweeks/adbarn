<?php include 'inc/header.php'; ?>

    <article>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2 class="tc">Terms & Privacy </h2>
            <hr>
            <div class="well well-md">
              <h3>First terms</h3>
              <hr>
              <p>
                Lorem ipsum dolor sit amet, est zril exerci tamquam an, mollis rationibus efficiendi in vis, usu soluta corrumpit id. Ne ius prima zril efficiendi, nam saepe delicatissimi ei. Volutpat similique qui id, inani libris eu vis. Senserit abhorreant duo an. Per te agam eloquentiam, sit eripuit contentiones no, cu eos nisl everti persecuti. Duis ullum vivendo qui no, id qui aperiri definitiones.
              </p>

              <p>
                Ei augue euismod has, et nec natum philosophia, no falli consetetur sit. Ferri habemus erroribus at qui. Et graeci putant sed, ius quod comprehensam no. Est cu vocent maiorum.
              </p>

              <p>
                Incorrupte intellegebat no eam, referrentur delicatissimi ad sit. Qui mazim referrentur no, ius cu assum tacimates. Numquam atomorum imperdiet qui at, ius an soluta mnesarchum voluptatum, sed scripta elaboraret ea. Qui ea velit dissentiet theophrastus, quo ei dicit blandit, an pro quis legendos. Solet dissentias sed ne, cu est eros bonorum. His torquatos comprehensam in, argumentum dissentias sit cu.
              </p>

              <h3>Other terms</h3>
              <hr>
              <p>
                Incorrupte intellegebat no eam, referrentur delicatissimi ad sit. Qui mazim referrentur no, ius cu assum tacimates. Numquam atomorum imperdiet qui at, ius an soluta mnesarchum voluptatum, sed scripta elaboraret ea. Qui ea velit dissentiet theophrastus, quo ei dicit blandit, an pro quis legendos. Solet dissentias sed ne, cu est eros bonorum. His torquatos comprehensam in, argumentum dissentias sit cu.
              </p>
              <p>
                Incorrupte intellegebat no eam, referrentur delicatissimi ad sit. Qui mazim referrentur no, ius cu assum tacimates. Numquam atomorum imperdiet qui at, ius an soluta mnesarchum voluptatum, sed scripta elaboraret ea. Qui ea velit dissentiet theophrastus, quo ei dicit blandit, an pro quis legendos. Solet dissentias sed ne, cu est eros bonorum. His torquatos comprehensam in, argumentum dissentias sit cu.
              </p>

              <h3>Final terms, with links</h3>
              <hr>
              <p>
                Incorrupte intellegebat no eam, referrentur delicatissimi ad sit. Qui mazim referrentur no, ius cu assum tacimates. Numquam atomorum imperdiet qui at, ius an soluta mnesarchum voluptatum, sed scripta elaboraret ea. Qui ea velit dissentiet theophrastus, quo ei dicit blandit, an pro quis legendos. Solet dissentias sed ne, cu est eros bonorum. His torquatos comprehensam in, argumentum dissentias sit cu.
              </p>
              <p>
                Incorrupte intellegebat no eam, referrentur delicatissimi ad sit. Qui mazim referrentur no, ius cu assum tacimates. Numquam atomorum imperdiet qui at, ius an soluta mnesarchum voluptatum, sed scripta elaboraret ea. Qui ea velit dissentiet theophrastus, quo ei dicit blandit, an pro quis legendos. Solet dissentias sed ne, cu est eros bonorum. His torquatos comprehensam in, argumentum dissentias sit cu.
              </p>

              <p>
                Lorem ipsum dolor sit amet, est zril exerci tamquam an, mollis rationibus efficiendi in vis, usu soluta corrumpit id. Ne ius prima zril efficiendi, nam saepe delicatissimi ei. Volutpat similique qui id, inani libris eu vis. Senserit abhorreant duo an. Per te agam eloquentiam, sit eripuit contentiones no, cu eos nisl everti persecuti. Duis ullum vivendo qui no, id qui aperiri definitiones.
              </p>

              <ul>
                <li><a href="">Source of our terms</a></li>
                <li><a href="">Lorem ipsum</a></li>
                <li><a href="">Etcetera</a></li>
                <li><a href="">Source of our terms</a></li>
                <li><a href="">Something else</a></li>
              </ul>

              <p>
                Ei augue euismod has, et nec natum philosophia, no falli consetetur sit. Ferri habemus erroribus at qui. Et graeci putant sed, ius quod comprehensam no. Est cu vocent maiorum.
              </p>
            </div>

          </div>
        </div>
      </div>
    </article>

<?php include 'inc/footer.php'; ?>
