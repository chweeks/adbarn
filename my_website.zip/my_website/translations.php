<?php include 'inc/header.php'; ?>

    <article>
      <div class="container tc">
        <div class="row">
          <div class="col-md-12">
            <h1>Coming soon!</h1>
            <i class="fa fa-clock-o fa-5x"></i>
            
          </div>
        </div>
      </div>
    </article>

<?php include 'inc/footer.php'; ?>

